Readme
======

- This program can be running on Linux or Unix.

- Using two terminals: one as the client and another one as the server.

## Compilation

- In the current directory, type:

    make

## Run

- Start the server first, type:

    ./server

- Then start the client, type:

    ./client
